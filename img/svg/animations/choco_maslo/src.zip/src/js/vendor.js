/**************************************/
/* Vendor JavaScript files supervisor */
/**************************************/

/* Third party */

/*//= ../../bower_components/jquery/dist/jquery.js */
//= ../../bower_components/bootstrap/dist/js/bootstrap.js
//= ../../bower_components/bootstrap-material-design/dist/js/ripples.js
//= ../../bower_components/bootstrap-material-design/dist/js/material.js
/*//= ../../bower_components/modernizr/modernizr.js */
//= ../../bower_components/social-likes/src/social-likes.js
//= ../../bower_components/css_browser_selector/css_browser_selector.js
