// This command is used to initialize some elements of Bootstrap Material and make them work properly
$.material.init();
