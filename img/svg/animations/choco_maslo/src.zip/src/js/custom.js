/**************************************/
/* Custom JavaScript files supervisor */
/**************************************/

$(document).ready(function() {
	$('.myFastClass').click(function(){
		$(this).hide();});
    /* Custom 

    //= ./common/material-init.js
    //= ./common/google-analytics.js
	*/
});